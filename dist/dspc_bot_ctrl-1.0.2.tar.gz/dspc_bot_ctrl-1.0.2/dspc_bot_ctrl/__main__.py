from dspc_bot_ctrl.dspc_bot import DSPCBOT


def main():
	DSPCBOT().init()


if __name__ == "__main__":
	main()